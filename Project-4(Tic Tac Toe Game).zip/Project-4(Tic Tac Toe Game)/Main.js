console.log('Welcome to my Website');

//Variable

let player1 = prompt('Enter the Name of Player-1', 'Guest1');
let player2 = prompt('Enter the Name of Player-2', 'Guest2');
let block = document.getElementsByClassName('block');
let whoseturn = document.getElementById('turn');
let button = document.getElementById('btn');
let winvedio = document.getElementById('vedio');
let turn = 'X';
let insideblock = document.getElementsByClassName('valueinput');
let congo = document.getElementById('head1');
let whowon = document.getElementById('head2');
let line=document.getElementById('line');
let iswon = true;
let chance = player1;
let clickaudio=new Audio('ting.mp3');
let winningaudio=new Audio('song.mp3');

whoseturn.innerHTML = `${chance} Turn`;

//change x and 0 after each turn.
function changeturnfunction() {
    if (turn == 'X') {
        return 'O';
    }
    else {
        return 'X';
    }
}

//check for the win

function checkwin() {  
    let win = [  //idx idx idx top left rotate
        [0, 1, 2, 4.6, 2, 0],
        [3, 4, 5, 14.6, 2, 0],
        [6, 7, 8, 24.6, 2, 0],

        [0, 3, 6, 15, -8, 90],
        [1, 4, 7, 15, 2, 90],
        [2, 5, 8, 15, 12, 90],

        [0, 4, 8, 14, 1.5, 45],
        [6, 4, 2, 14, 2.5, 135]
    ];

    win.forEach((element) => {
        if ((insideblock[element[0]].innerHTML === insideblock[element[1]].innerHTML) && (insideblock[element[1]].innerHTML === insideblock[element[2]].innerHTML) && (insideblock[element[1]].innerHTML !== '' && insideblock[element[0]].innerHTML !== '' && insideblock[element[2]].innerHTML !== '')) {
            let winner = player2;
            iswon = false;
            if (insideblock[element[0]].innerHTML === 'X') {
                winner = player1;
            }

            line.style.display= `block`;
            line.style.left=`${element[4]}vw`;
            line.style.top=`${element[3]}vw`;
            line.style.transform=`rotate(${element[5]}deg)`;
            winningaudio.play();

            setTimeout(() => {
                winvedio.classList.remove('vedioinvisible');
                winvedio.classList.add('vediovisible');
                whowon.innerHTML = `${winner} Won the Game`;
                document.getElementById('dance').style.display=`block`;
                setTimeout(() => {
                    congo.classList.remove('congo');
                    congo.classList.add('visible');
                    whowon.classList.remove('playwon');
                    whowon.classList.add('visible');
                }, 2000);

            }, 3000);

            setTimeout(() => {
                document.getElementById('game').style.display= `none`;
            }, 2500);
        }
    })
}

//Main Working

Array.from(block).forEach((element) => {
    element.addEventListener('click', () => {
        if (iswon) {
            if (element.getElementsByClassName('valueinput')[0].innerHTML == "") {
                clickaudio.play();
                element.getElementsByClassName('valueinput')[0].innerHTML = turn;
                turn = changeturnfunction();
                checkwin();
                if (turn === 'O') {
                    chance = player2;
                }
                else {
                    chance = player1;
                }


                if (iswon) {
                    whoseturn.innerHTML = `${chance} Turn`;
                }
                else {
                    whoseturn.innerHTML = `Game Over`;
                }
            }
        }
    })
})

//Make reset button working

